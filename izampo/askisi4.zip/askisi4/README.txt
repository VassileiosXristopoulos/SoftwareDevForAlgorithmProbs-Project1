javac App.java 
java App