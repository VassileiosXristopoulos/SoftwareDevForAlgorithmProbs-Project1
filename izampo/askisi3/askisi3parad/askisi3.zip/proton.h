#pragma once
#include "fermion.h"
#include <iostream>
#include <string>
using namespace std;

class proton :public fermion{
public:
	proton();
	~proton();
};
